/**
 * Admin Enqueue Script
 *
 * @package
 */

jQuery( document ).ready( function () {
	'use strict';
	jQuery( '.wpssle-support' ).parent().attr( 'target', '_blank' );
} );

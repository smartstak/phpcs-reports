/**
 * Admin Enqueue Script
 *
 * @package wpsyncsheets-gravity-forms
 */

jQuery( document ).ready(
	function () {
		jQuery( '.wpsslgf-support' ).parent().attr( 'target','_blank' );
	}
);

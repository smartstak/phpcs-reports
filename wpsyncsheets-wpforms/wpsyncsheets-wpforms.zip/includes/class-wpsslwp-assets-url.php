<?php
/**
 * Class for Assets URL method
 *
 * @package wpsyncsheets-wpforms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Final class of WPSSLWP_Assets_Url
 */
final class WPSSLWP_Assets_URL {

	/**
	 * Assets URL builder method
	 *
	 * @param string $type js|css.
	 * @param string $filename  File name without extension.
	 * @param string $dev_path  Development relative path.
	 * @param string $prod_path Production relative path.
	 */
	public static function assets_url( string $type, string $filename, string $dev_path, string $prod_path ): string {

		$is_production = (
			defined( 'WPSSLWP_ENVIRONMENT' ) &&
			WPSSLWP_ENVIRONMENT === 'production'
		);

		$dev_file  = trailingslashit( WPSSLWP_PATH ) . trailingslashit( $dev_path ) . $filename . '.' . $type;
		$prod_file = trailingslashit( WPSSLWP_PATH ) . trailingslashit( $prod_path ) . $filename . '.' . $type;

		if ( $is_production && file_exists( $prod_file ) ) {
			return WPSSLWP_URL . trailingslashit( $prod_path ) . $filename . '.' . $type;
		}
		return WPSSLWP_URL . trailingslashit( $dev_path ) . $filename . '.' . $type;
	}
}

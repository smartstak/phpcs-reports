/**
 * Admin Enqueue Script
 *
 * @package wpsyncsheets-wpforms
 */

jQuery( document ).ready(
	function () {
		"use strict";
		jQuery( '.wpsslwp-support' ).parent().attr( 'target','_blank' );
	}
);

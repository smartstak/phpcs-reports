<?php
/**
 * Plugin Name: WPSyncSheets Lite For WPForms
 * Plugin URI: https://www.wpsyncsheets.com/wpsyncsheets-for-wpforms/
 * Description: Save all WPForms entries to Google Spreadsheet.
 * Author: Creative Werk Designs
 * Author URI: http://www.creativewerkdesigns.com/
 * Text Domain: wpsswp
 * Domain Path: /languages/
 * Version: 1.6.9.5
 *
 * @package     wpsyncsheets-wpforms
 * @author      Creative Werk Designs
 * @Category    Plugin
 * @copyright   Copyright (c) 2025 Creative Werk Designs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( !function_exists('is_plugin_active') ) {
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
}

if ( ! get_option( 'active_wpsyncsheets_wpforms' ) && ! is_plugin_active( 'wpsyncsheets-for-wpforms/wpsyncsheets-for-wpforms.php' ) ) {

	// Changed.
	define( 'WPSSLWP_ENVIRONMENT', 'production' ); // or development.
	// Plugin version.
	define( 'WPSSLWP_VERSION', '1.6.9.5' );
	// Plugin URL.
	define( 'WPSSLWP_URL', plugin_dir_url( __FILE__ ) );
	// Plugin directory.
	define( 'WPSSLWP_DIR', plugin_dir_path( __FILE__ ) );
	define( 'WPSSLWP_PLUGIN_ITEM_ID', '1392' );
	define( 'WPSSLWP_PLUGIN_SECURITY', 1 );
	define( 'WPSSLWP_PATH', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
	define( 'WPSSLWP_BASE_FILE', basename( dirname( __FILE__ ) ) . '/wpsyncsheets-lite-wpforms.php' );
	define( 'WPSSLWP_DIRECTORY', dirname( plugin_basename( __FILE__ ) ) );
	define( 'WPSSLWP_PLUGIN_SLUG', WPSSLWP_DIRECTORY . '/' . basename( __FILE__ ) );
	define( 'WPSSLWP_PRO_VERSION_URL', 'https://www.wpsyncsheets.com/wpsyncsheets-for-wpforms/' );
	define( 'WPSSLWP_DOCUMENTATION_URL', 'https://docs.wpsyncsheets.com/wpsswp-setup-guide/' );
	define( 'WPSSLWP_DOC_SHEET_SETTING_URL', 'https://docs.wpsyncsheets.com/wpsswp-google-sheets-api-settings/' );
	define( 'WPSSLWP_SUPPORT_URL', 'https://wordpress.org/support/plugin/wpsyncsheets-wpforms/' );
	define( 'WPSSLWP_DOC_MENU_URL', 'https://docs.wpsyncsheets.com' );
	define( 'WPSSLWP_BUY_PRO_VERSION_URL', 'https://www.wpsyncsheets.com/wpsyncsheets-for-wpforms/?utm_source=liteplugin&utm_medium=admindescription&utm_campaign=wpsyncsheets_lite_for_wpforms/' );

	/**
	 * Check WPForms plugin is active or not.
	 *
	 * @param string $plugin Plugin Array.
	 */
 
    if ( ! class_exists( 'WPSSLWP_Dependencies' ) ) {
	    require_once trailingslashit( dirname( __FILE__ ) ) . 'includes/class-wpsslwp-dependencies.php';
    }
	
	
	if ( WPSSLWP_Dependencies::wpsslwp_is_wpforms_plugin_active() ) {
		/**
		 * Remove capability.
		 */
		function wpsslwp_remove_custom_capability_from_all_roles() {
			// Get all roles.
			global $wp_roles;

			// Ensure $wp_roles is properly initialized.
			if ( ! $wp_roles instanceof WP_Roles ) {
				return;
			}

			// Iterate through each role.
			foreach ( $wp_roles->roles as $role_name => $role_info ) {
				$role = get_role( $role_name );
				if ( $role ) {
					if ( $role->has_cap( 'edit_wpsyncsheets_wpforms_lite_main_settings' ) ) {
						$role->remove_cap( 'edit_wpsyncsheets_wpforms_lite_main_settings' );
					}
					if ( $role->has_cap( 'edit_wpsyncsheets_wpforms_lite_form_settings' ) ) {
						$role->remove_cap( 'edit_wpsyncsheets_wpforms_lite_form_settings' );
					}
				}
			}
		}
		register_deactivation_hook( __FILE__, 'wpsslwp_remove_custom_capability_from_all_roles' );

		/**
		 * Add capability.
		 */

		function wpsslwp_add_custom_capability_to_specific_roles() {
			$specific_roles = array( 'administrator' );

			foreach ( $specific_roles as $role_name ) {
				$role = get_role( $role_name );
				if ( $role ) {
					if ( ! $role->has_cap( 'edit_wpsyncsheets_wpforms_lite_main_settings' ) ) {
						$role->add_cap( 'edit_wpsyncsheets_wpforms_lite_main_settings' );
					}

					if ( ! $role->has_cap( 'edit_wpsyncsheets_wpforms_lite_form_settings' ) ) {
						$role->add_cap( 'edit_wpsyncsheets_wpforms_lite_form_settings' );
					}
				}
			}
		}

		register_activation_hook( __FILE__, 'wpsslwp_add_custom_capability_to_specific_roles' );
		add_action( 'init', 'wpsslwp_add_custom_capability_to_specific_roles' );

		// Add methods if WPForms Lite is active.
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wpsslwp_add_action_links', 10, 1 );
		/**
		 * Add action link if WPForms is active.
		 *
		 * @param array $links .
		 * @return array
		 */

		function wpsslwp_add_action_links( $links ) {
			$wpsslwplinks = array(
				'<a href="' . esc_url( admin_url( 'admin.php?page=wpsyncsheets-wpforms' ) ) . '">' . esc_html__( 'Settings', 'wpsswp' ) . '</a>',
				'<a style="font-weight:bold; color: #0040ff;" target="_blank" href="' . WPSSLWP_BUY_PRO_VERSION_URL . '">Upgrade to Pro</a>',
			);
			return array_merge( $links, $wpsslwplinks );
		}

		// Define the class and the function.
		require_once dirname( __FILE__ ) . '/src/class-wpsyncsheets-wpforms.php';
		wpsslwp();
	} else {
		add_action( 'admin_notices', 'wpsslwp_admin_notice' );
		if ( ! function_exists( 'wpsslwp_admin_notice' ) ) {
			/**
			 *  Add admin notice.
			 */

			function wpsslwp_admin_notice() {
				echo '<div class="notice error">
					<div>
						<p>' . esc_html__( 'WPSyncSheets For WPForms plugin requires ', 'wpsswp' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/wpforms-lite/' ) . '" target = "_blank">' . esc_html__( 'WPForms Lite', 'wpsswp' ) . '</a>' . esc_html__( ' OR ', 'wpsswp' ) . '<a href="' . esc_url( 'https://wpforms.com/' ) . '" target = "_blank">' . esc_html__( 'WPForms', 'wpsswp' ) . '</a>' . esc_html__( ' plugin to be active!', 'wpsswp' ) . '</p>
					</div>
				</div >';
			}
		}
	}
}
=== WPSyncSheets For WPForms - Google Sheets Connector for WPForms & Real‑Time Data Export ===

Contributors: creativewerkdesigns, arpitgshah
Tags: WPForms, google sheets, form entries, wpforms google sheets, export wpforms entries, form export
Requires at least: 5.5
Tested up to: 6.8.2
Stable tag: 1.6.9.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect WPForms to Google Sheets and automatically sync form entries in real-time. Eliminate manual data entry and simplify your workflow.

== Description ==

<strong>WPSyncSheets For WPForms </strong> -  A powerful and user-friendly solution to automatically save entries from both WPForms Lite and WPForms Pro directly into a single Google Spreadsheet. With this addon, every time a user submits a form without any code, their data is instantly synced to your connected spreadsheet. Easily manage and organize form submissions in one place.

= 🚀 Key Features =
🔄 Real-time export of WPForms entries to Google Sheets
✅ Automated & runtime syncing – no manual exports needed
🧩 Field-to-column mapping for custom spreadsheet structures
📄 Auto-create Google Spreadsheet & sheets from feed settings
📌 Option to freeze header row in Google Sheets
🕒 Auto-add submission date & time for each form entry
📥 View, clear, or export Google Sheet data from the plugin dashboard
⚙️ Tested with WPForms Lite & Pro, WordPress 6.8.2, and PHP 8.3

= 💡 Why Use This Plugin? =
<strong>Real-time sync: </strong>No more manual exports — your sheets update automatically
<strong>Collaboration ready: </strong>Easily share sheets with team members or stakeholders
<strong>Fully Customizable: </strong>You can design your forms the way you want
<strong>Customizable sheets: </strong>Control what you export and how it's formatted

= 📂 Download Sample Sheets =
[View Sample Exported Entries Sheet](https://docs.google.com/spreadsheets/d/1pRsPlwQ-MXPKP84v3LVVj_dfmkosmznoM3d820i8ZXA/edit?gid=743464540#gid=743464540&range=A90)

= 🛠️ How to Export WPForms Entries to Google Sheets =

1. Install and activate the plugin
2. Connect to Google Drive via API (Client ID, Secret, and Token)
3. Go to the form settings → WPSyncSheets Feed Settings
4. Enable the feeds and map it.
5. Save the Setting
6. New submissions will auto-export to Google Sheets

=  ▶ How To's Video =

### How to Export WPForms?

https://youtu.be/6pQFBm7KKJ0?si=I0CMY-O50v091E8Y

🔗 [Live Demo – Click Here](https://demo.wpsyncsheets.com/wpsyncsheets-for-wpforms/)

= 🧪 Demo Testing Instructions =

1. Fill out the sample form
2. Submit your data
3. Click the spreadsheet link to view real-time exported entries

= 🔒 Upgrade to Pro =

The [Pro version](https://www.wpsyncsheets.com/wpsyncsheets-for-wpforms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description) unlocks powerful features:

<blockquote>

&#9989; <strong>All the features</strong> in the free plugin (<strong>entries export, create new google sheet, etc</strong>)
&#9989; Custom <strong>column mapping</strong> – choose your own headers and order
&#9989; <strong>Edit or Sorting</strong> existing sheet headers directly from settings.
&#9989; <strong> Conditional logic </strong> – sync entries only when specific rules match
&#9989; <strong>Submission time, user info, IP address </strong> logging
&#9989; <strong>Save Files:</strong> Automatically store uploaded files in the plugin folder and add download links to your Google Sheet.

</blockquote>

= 📘 Documentation & Support =

* Check these [help docs](https://docs.wpsyncsheets.com/wpsswp-plugin-features/)
* Reach out to our [support team](https://wordpress.org/support/plugin/wpsyncsheets-wpforms/)

= 📣 Trusted by Over 10,000+ Customers =

Trusted by businesses, developers, and marketing teams to automate WPForms data syncing and streamline client reporting via Google Sheets.

= 🔔 Stay Updated = 

Subscribe to the [WPSyncSheets Newsletter](https://www.wpsyncsheets.com/#newsletter) and get tips, updates, and exclusive discounts delivered straight to your inbox!

###Relevant Import-Export Google Sheets Plugins###

Other useful plugins from WPSyncSheets to import and export data from WordPress websites to Google Sheets. 

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-woocommerce/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description">WPSyncSheets For WooCommerce</a>:  Import Export for WooCommerce orders, products, customers, coupons, and events.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-elementor/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description">WPSyncSheets For Elementor</a>: Migrates Elementor form entries to Google Sheets, maps form fields to the spreadsheet columns, and automatically updates sheets when form entries are submitted.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-gravity-forms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description">WPSyncSheets For Gravity Forms</a>: Sync Gravity Forms entries to Google Sheets allowing form data transfer to specified spreadsheet columns in real-time.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-core/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description">WPSyncSheets For Core</a>: Enables import export WordPress posts and pages to and from Google Sheets, allowing users to bulk edit content in the spreadsheet and sync changes back to WordPress.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-document-library-pro/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description">WPSyncSheets For Document Library Pro</a>: Sync Document Library Pro entries with Google Sheets allowing for two-way updates between the plugin entries and spreadsheet data. 

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-contact-form-7/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description">WPSyncSheets For Contact Form 7</a>: Transfers Contact Form 7 entries to Google Sheets, maps form fields to spreadsheet columns, and updates sheets upon form submission.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-ninjaforms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description">WPSyncSheets For Ninja Forms</a>: Migrates Ninja Forms entries to Google Sheets, maps form fields to spreadsheet columns, and updates sheets in real-time. 

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-fluent-forms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description">WPSyncSheets For Fluent Forms</a>: Sync Fluent Forms entries to Google Sheets, and automatically transfer form data to designated spreadsheet columns upon submission.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-formidable-forms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description">WPSyncSheets For Formidable Forms</a>: Adds Formidable Forms entities to Google Sheets maps form fields to spreadsheet columns and automatically updates sheets when forms are submitted.

= About WPSyncSheets =

<a rel="nofollow" href="https://www.wpsyncsheets.com/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description">WPSyncSheets</a> is a leading plugin suite built to connect WordPress and WooCommerce platforms with <strong>Google Sheets</strong>. Our mission is to help businesses automate data transfer, simplify operations, and reduce repetitive tasks through real-time, two-way data synchronization. 

With over 9+ purpose-built plugins, WPSyncSheets enables:

* Smooth export/import of WooCommerce and WordPress data
* Bulk content updates through spreadsheets
* Live syncing of form submissions across popular form plugins
* Easy spreadsheet-based product management

Whether you're running an eCommerce store, collecting leads, or managing blog content, WPSyncSheets lets you <strong>automate your workflow</strong>—no code required.

👉 Learn more on our [Official Website](https://www.wpsyncsheets.com/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description)
📈 Upgrade to [WPSyncSheets Pro](https://www.wpsyncsheets.com/wpsyncsheets-for-wpforms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description) for the full automation suite
💬 Have questions? Contact Our [Support Team](https://www.wpsyncsheets.com/support-tickets/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-wpforms&utm_medium=description)

== Frequently Asked Questions ==

= Why isn’t form data sent to Google Sheets—or just spinning indefinitely? =

This usually happens when:

- Your Google authentication token needs reauthorization. Visit the plugin settings and reauthorize.
- Google Sheets and Drive APIs are not enabled on your Google account. Ensure both are activated in your Google Cloud Console.
=  Will the submission date and time be saved? =
Yes. Each synced entry includes the exact date and time of submission in dedicated columns.

= Can I connect multiple WPForms to different Google Sheets? =
Yes! You can configure each WPForm individually to sync with a unique Google Spreadsheet or specific sheet tab, offering complete flexibility.

= Can I map form fields to specific sheet columns? =
Yes, with the Pro version, you can map form fields to custom column headers for precise data structuring.

=  Is my form data stored securely? =
Yes. All form data remains within your WordPress site and your authenticated Google account. No external servers or third-party services are used.

= Are uploaded files saved and added to Google Sheets? =
Yes, in the Pro version. File uploads are saved in the plugin folder, and a link is automatically added to the Google Sheet entry.

= Can I freeze the sheet header row? =
Yes. The plugin includes an option to freeze or unfreeze the header row in Google Sheets.

= Can I view, clear, or download the connected Google Sheet? =
Yes. You can access your linked Google Sheet from the plugin settings with options to view, clear, or download it.

= What should I do if I see a "This app isn't verified" warning from Google? =
If you created the Google API credentials yourself, click “Advanced” and then “Go to project” to continue. It’s safe if you’re the app owner.

= Why is there a "range exceeds grid limits" error in Sheets? =
This occurs when the sheet reaches its maximum row or column limit. Simply increase the number of rows in your Google Sheet to fix this.

== Installation ==

1. Upload the entire `wpsyncsheets-wpforms` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the **Plugins** screen (**Plugins > Installed Plugins**).

You will find **WPSyncSheets For WPForms** menu in your WordPress admin screen.

For basic usage, have a look at the [plugin's Documentation](https://docs.wpsyncsheets.com/wpsswp-plugin-features/).

== Screenshots ==

1. Google API Integration Settings
2. General Settings
3. Sheet Headers
4. Google Spreadsheet Entries

== Changelog ==

= 1.6.9.5 =

* Tested with WPForms 1.9.8.4
* Tested with WordPress 6.9

= 1.6.9.4 =

* Add "Leave a Review" Functionality

= 1.6.9.3 =

* Optimized code

= 1.6.9.2 =

* Tested with WPForms 1.9.7.3
* Tested with WordPress 6.8.2

= 1.6.9.1 =

* Add "Upgrade to Pro" link

= 1.6.9 =

* Add Dashboard Tab

= 1.6.8 =

* Add Feedback Form Popup
* UI & UX Changes

= 1.6.7 =

* Modified Submission Date and Submission Time in sheet headers

= 1.6.6 =

* Optimized code

= 1.6.5 =

* UI/UX Changes

= 1.6.4 =

* Tested with WordPress 6.8

= 1.6.3 =

* Fixed: Multisite plugin activation not being recognized.
* Fixed: Resolved an issue with the refresh token.

= 1.6.2 =

* Added is_plugin_active() function_exists for improved security in plugin operations.

= 1.6.1 =

* Performed user capability check for secure operation execution.

= 1.6 =

* Added nonce functionality for improved security in plugin operations.

= 1.5.2 =

* Optimized code

= 1.5.1 =

* Tested with WordPress 6.7.1
* Updated & Tested with Guzzle Library 7.9.2

= 1.5 =

* Optimized code

= 1.4 =

* Enable\Disable Sheet Headers
* Submission Date & Time options
* Clear spreadsheet
* Optimized code

= 1.3 =

* Optimized code

= 1.2 =

* Optimized code
* Coding Standards Improvement & Security Patch

= 1.1 =

* Optimized code
* Download Spreadsheet Button
* Load Library

= 1.0 =

* Initial Version
const path = require("path");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const RemoveEmptyScriptsPlugin = require( 'webpack-remove-empty-scripts' );

module.exports = {
    entry: {
        "wpsslwp-admin-script": "./assets/js/wpsslwp-admin-script.js",
        "wpsslwp-general": "./assets/js/wpsslwp-general.js",
        "admin-feedback": "./feedback/js/admin-feedback.js",
        "wpsslwp-admin-plugin-setting-style": "./assets/css/wpsslwp-admin-plugin-setting-style.css",
        "wpsslwp-admin-review": "./assets/css/wpsslwp-admin-review.css",
        "wpsslwp-admin-style": "./assets/css/wpsslwp-admin-style.css",
        "wpsslwp-general-notice-style": "./assets/css/wpsslwp-general-notice-style.css",
        "admin-feedback-style": "./feedback/css/admin-feedback-style.css"
    },

    output: {
        path: path.resolve(__dirname, "./assets"),
        filename: "js/build/[name].js",
        clean: false,
    },

    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: "babel-loader" // optional, @wordpress/scripts provides env config automatically
            },
            {
                test: /\.(scss|css)$/,
                use: [
                    MiniCssExtractPlugin.loader,
                    {
                        loader: "css-loader",
                        options: {
                            url: false // important for WP — avoids image path rewriting
                        }
                    },
                    {
                        loader: "postcss-loader",
                        options: {
                            postcssOptions: {
                                plugins: [require("autoprefixer")]
                            }
                        }
                    },
                    "sass-loader"
                ]
            }
        ]
    },

    plugins: [
        new RemoveEmptyScriptsPlugin(),
        new MiniCssExtractPlugin({
            filename: "css/build/[name].css"
        })
    ]
};

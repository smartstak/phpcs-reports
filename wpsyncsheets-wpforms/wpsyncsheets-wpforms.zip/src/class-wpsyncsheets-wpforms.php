<?php
	/**
	 * Main WPSyncSheets_WPForms namespace.
	 *
	 * @since 1.0.0
	 * @package wpsyncsheets-wpforms
	 */

namespace WPSyncSheets_WPForms {
	/**
	 * Main WPSyncSheets_WPForms class.
	 *
	 * @since 1.0.0
	 * @package wpsyncsheets-wpforms
	 */
	final class WPSyncSheets_WPForms {
		/**
		 * Instance of this class.
		 *
		 * @since 1.0.0
		 *
		 * @var \WPSyncSheets_WPForms\WPSyncSheets_WPForms
		 */
		private static $instance;
		/**
		 * Plugin version for enqueueing, etc.
		 *
		 * @since 1.0.0
		 *
		 * @var string
		 */
		public $version = '';
		/**
		 * Main WPSyncSheets_WPForms Instance.
		 * Only one instance of WPSyncSheets_WPForms exists in memory at any one time.
		 * Also prevent the need to define globals all over the place.
		 *
		 * @since 1.0.0
		 *
		 * @return WPSyncSheets_WPForms
		 */
		public static function instance() {
			if ( null === self::$instance || ! self::$instance instanceof self ) {
				self::$instance = new self();
				self::$instance->constants();
				self::$instance->includes();
				add_action( 'init', array( self::$instance, 'load_textdomain' ), 10 );
			}
			return self::$instance;
		}
		/**
		 * Setup plugin constants.
		 * All the path/URL related constants are defined in main plugin file.
		 *
		 * @since 1.0.0
		 */
		private function constants() {
			$this->version = WPSSLWP_VERSION;
		}
		/**
		 * Load the plugin language files.
		 *
		 * @since 1.0.0
		 */
		public function load_textdomain() {
			// If the user is logged in, unset the current text-domains before loading our text domain.
			// This feels hacky, but this way a user's set language in their profile will be used,
			// rather than the site-specific language.
			if ( is_user_logged_in() ) {
				unload_textdomain( 'wpsswp' );
			}
			load_plugin_textdomain( 'wpsswp', false, WPSSLWP_DIRECTORY . '/languages/' );
		}
		/**
		 * Include files.
		 *
		 * @since 1.0.0
		 */
		private function includes() {
			// Global Includes.
			require_once WPSSLWP_PATH . '/includes/class-wpsslwp-google-api.php';
			require_once WPSSLWP_PATH . '/includes/class-wpsslwp-google-api-functions.php';
			require_once WPSSLWP_PATH . '/includes/class-wpsslwp-assets-url.php'; // Changed.
			require_once WPSSLWP_PATH . '/includes/class-wpsslwp-plugin-settings.php';
			require_once WPSSLWP_PATH . '/includes/class-wpsslwp-service.php';
			require_once WPSSLWP_PATH . '/includes/class-wpsslwp-notifications.php';
			require_once WPSSLWP_PATH . '/feedback/users-feedback.php';
		}

	}
}

namespace {
	/**
	 * The function which returns the one WPSSLWP instance.
	 *
	 * @since 1.0.0
	 *
	 * @return WPSSLWP\wpsslwp
	 */
	function wpsslwp() {
		return WPSyncSheets_WPForms\WPSyncSheets_WPForms::instance();
	}
	class_alias( 'WPSyncSheets_WPForms\WPSyncSheets_WPForms', 'WPSyncSheets_WPForms' );
}

=== Export WooCommerce Orders, Products, Customers & Coupons to Google Sheets ===

Contributors: creativewerkdesigns, arpitgshah
Tags: woocommerce export, export woocommerce orders, export woocommerce products, google sheet, export woocommerce customers, export woocommerce coupons
Requires at least: 5.3
Tested up to: 6.8.2
Requires PHP: 5.6
Stable tag: 2.0.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Export WooCommerce orders, products, customers, and coupons to Google Sheets automatically in real-time.

== Description ==

<strong>WPSyncSheets For WooCommerce Lite</strong> is a powerful, real-time export plugin that lets you automatically sync <strong>WooCommerce orders, products, customers, and coupons to Google Sheets</strong> — without manual work.

With its intuitive <strong>'Click to Sync'</strong> feature, you can effortlessly back up store data, share business insights with your team, or migrate WooCommerce content between sites. Each data type is organized in its own tab inside a single Google Sheet for clarity and easy access.

Whether you're running a small store or managing a complex WooCommerce setup, this plugin simplifies your data management by offering a clean and customizable export system with automated syncing and advanced features.

As a powerful <strong>automated and run-time solution</strong>, WPSyncSheets updates your data in real-time, eliminating the need for manual intervention and ensuring that your information is always updated.

= 🔑 Key Features =

* Export <strong>WooCommerce Orders</strong> to Google Sheets
* Export <strong>Products, Customers, and Coupons</strong>
* Supports <strong>bulk export</strong> of all data types
* Export <strong>all product types:</strong> simple, variable, grouped & external
* Automatically create and manage <strong>separate sheets</strong> for each data type
* <strong>Enable/disable data types</strong> or customize headers
* Download data as <strong>Excel files</strong> (orders, products, customers, coupons)
* Export order data based on <strong>status</strong>
* Compatible with <strong>WooCommerce 9.8.5, WordPress 6.8.1, PHP 8.3</strong>
* <strong>100% HPOS Compatible</strong>
* Supports <strong>French, German, Dutch & Chinese</strong>

= 🚀 Why Use This Plugin? = 

* <strong>Real-time sync:</strong> No more manual exports — your sheets update automatically
* <strong>Data backup:</strong> Keep a live copy of your store data in Google Sheets
* <strong>Collaboration ready:</strong> Easily share sheets with team members or stakeholders
* <strong>Customizable sheets:</strong> Control what you export and how it's formatted

= 📂 Sample Export Sheets =
[Sample Sheets of Exported Orders](https://docs.google.com/spreadsheets/d/1nyB8kxQcAeSUXkDjhbYJLwBdOSuxRcrCeARWJ6W7PWY/edit)
[Sample Sheets of Exported Products](https://docs.google.com/spreadsheets/d/1nyB8kxQcAeSUXkDjhbYJLwBdOSuxRcrCeARWJ6W7PWY/edit?gid=920889803#gid=920889803)
[Sample Sheets of Exported Customers](https://docs.google.com/spreadsheets/d/1nyB8kxQcAeSUXkDjhbYJLwBdOSuxRcrCeARWJ6W7PWY/edit?gid=583764156#gid=583764156)
[Sample Sheets of Exported Coupons](https://docs.google.com/spreadsheets/d/1nyB8kxQcAeSUXkDjhbYJLwBdOSuxRcrCeARWJ6W7PWY/edit?gid=554908772#gid=554908772)


### How to Export WooCommerce Orders?

https://youtu.be/jh5ErgluSVU?si=WifvUr5lIa3BP3dg

### How to Export WooCommerce Products?

https://youtu.be/00cNpysSQz0?si=SowUQbG8S9mRc_hw

### How to Export WooCommerce Coupons?

https://youtu.be/VVK-4b0W2zc?si=4UX1gYTs0JuF2lE_

### How to Export WooCommerce Customers?

https://youtu.be/AZqM9stSKWg?si=IRTNiA6JpuXH7QTr



### How to Import WooCommerce Orders? (Pro)

https://www.youtube.com/watch?v=rtU7-jnasFg

### How to Import WooCommerce Products? (Pro)

https://www.youtube.com/watch?v=MZLtSBKCGGM

### How to Import WooCommerce Coupons? (Pro)

https://www.youtube.com/watch?v=FjGlhasFoJQ

### How to Import WooCommerce Customers? (Pro)

https://www.youtube.com/watch?v=NRYa_8H1LfQ


= 📷 Live Demo =

Test the plugin in action here:

Easily Export WooCommerce Data to Google Sheets: [Live demo ](https://demo.wpsyncsheets.com/wpsyncsheets-for-woocommerce/)

= 📋 Instructions for testing demo =

1. Add any product to 'Add to Cart' → 'View Cart' → 'Proceed to Checkout' button
2. Fill out billing info (real or test) and place the order
3. Click on 'View Your Orders in Spreadsheet' to see WooCommerce data in Google Sheets

= 📌 Setup Instructions =

1. Install and activate the plugin
2. Connect your Google account via API (Client ID, Secret Key & Token)
3. Configure the export settings (orders, products, customers, coupons)
4. "Click to Sync" — your existing WooCommerce data will be sent to Google Sheets
5. Every new order, product, customer, or coupon is instantly added to your connected Google Sheets.

= 📘 Documentation & Support =

* Check these [help docs](https://docs.wpsyncsheets.com/wpssw-introduction/)
* Reach out to our [support team](https://wordpress.org/support/plugin/wpsyncsheets-woocommerce/)

= 🔒 Need Imports Too? Upgrade to Pro =

The [Pro Version](https://www.wpsyncsheets.com/wpsyncsheets-for-woocommerce/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description) lets you import orders, products, customers, coupons, and events from Google Sheets to WooCommerce — in addition to all the export features.

<strong>Import Export For WooCommerce (Pro Version) Features</strong>

<blockquote>

&#9989; <strong>All the features</strong> in the free plugin (<strong>data export, bulk export, etc</strong>)
&#9989; <strong>Import orders</strong> from Google Sheets to WooCommerce
&#9989; <strong>Import products</strong> from Google Sheets to WooCommerce
&#9989; <strong>Import coupons</strong> from Google Sheets to WooCommerce
&#9989; <strong>Import customers</strong> from Google Sheets to WooCommerce
&#9989; <strong>Import export events</strong> from Google Sheets to WooCommerce
&#9989; <strong>Bulk Import</strong> orders, products, coupons, customers, & events
&#9989; <strong>Auto field mapping</strong> in Google Sheets 
&#9989; Enable, disable, or custom-create <strong>sheet headers</strong>
&#9989; <strong>Add, modify, delete</strong> order, product, customer, coupons and events data within Google Sheets 
&#9989; <strong>Schedule automatic imports</strong> of data from Google Sheets
&#9989; <strong>Schedule automatic export</strong> from WooCommerce to Google Sheets
&#9989; <strong>Schedule auto-export data</strong> from WooCommerce to Google Sheets
&#9989; <strong>Advanced filters</strong> to selectively import or export data
&#9989; Generate <strong>visual graphs</strong> into Google Sheets
&#9989; Import export <strong>custom field</strong> data from ACF Lite or Pro
&#9989; Import export WooCommerce products <strong>category-wise</strong> 
&#9989; Import export <strong>product attributes</strong>
&#9989; Export data from WooCommerce to Google Sheets data within a <strong>date range</strong>
&#9989; <strong>Freeze headers</strong> & change <strong>row background color</strong> in Google Sheets
&#9989; <strong>Compatible with 45+</strong> popular WooCommerce & WordPress plugins
&#9989; <strong>Supports multisite</strong>

</blockquote>

= Download Sample Sheets Pro =
[Sample Sheets of Products Sold Bar Graph](https://docs.google.com/spreadsheets/d/1nyB8kxQcAeSUXkDjhbYJLwBdOSuxRcrCeARWJ6W7PWY/edit?gid=1921108293#gid=1921108293)
[Sample Sheets of Total Orders Line Graph](https://docs.google.com/spreadsheets/d/1nyB8kxQcAeSUXkDjhbYJLwBdOSuxRcrCeARWJ6W7PWY/edit?gid=1885649160#gid=1885649160)
[Sample Sheets of Sales Orders Bar Graph](https://docs.google.com/spreadsheets/d/1nyB8kxQcAeSUXkDjhbYJLwBdOSuxRcrCeARWJ6W7PWY/edit?gid=1885649160#gid=1885649160)

= 📣 Trusted by Over 10,000+ Customers =

Trusted by online retailers, developers, and marketing teams globally to streamline WooCommerce data management.

= 🔔 Stay Updated = 

Subscribe to the [WPSyncSheets Newsletter](https://www.wpsyncsheets.com/#newsletter) and get tips, updates, and exclusive discounts delivered straight to your inbox!

###Relevant Import-Export Google Sheets Plugins by WPSyncSheets###

Other useful plugins from WPSyncSheets to import and export data from WordPress websites to Google Sheets. 

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-gravity-forms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description">WPSyncSheets For Gravity Forms</a>:  Sync Gravity Forms entries to Google Sheets allowing form data transfer to specified spreadsheet columns in real-time.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-elementor/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description">WPSyncSheets For Elementor</a>: Migrates Elementor form entries to Google Sheets, maps form fields to the spreadsheet columns, and automatically updates sheets when form entries are submitted.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-core/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description">WPSyncSheets For Core</a>: Enables import export WordPress posts and pages to and from Google Sheets, allowing users to bulk edit content in the spreadsheet and sync changes back to WordPress.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-document-library-pro/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description">WPSyncSheets For Document Library Pro</a>: Sync Document Library Pro entries with Google Sheets allowing for two-way updates between the plugin entries and spreadsheet data. 

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-contact-form-7/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description">WPSyncSheets For Contact Form 7</a>: Transfers Contact Form 7 entries to Google Sheets, maps form fields to spreadsheet columns, and updates sheets upon form submission.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-wpforms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description">WPSyncSheets For WPForms</a>: Adds WPForms entries to Google Sheets and transfers form data to specified spreadsheet columns when forms are submitted. 

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-wpforms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description">WPSyncSheets For Ninja Forms</a>: Migrates Ninja Forms entries to Google Sheets, maps form fields to spreadsheet columns, and updates sheets in real-time. 

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-fluent-forms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description">WPSyncSheets For Fluent Forms</a>: Sync Fluent Forms entries to Google Sheets, and automatically transfer form data to designated spreadsheet columns upon submission.

<a rel="nofollow" href="https://www.wpsyncsheets.com/wpsyncsheets-for-formidable-forms/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description">WPSyncSheets For Formidable Forms</a>: Adds Formidable Forms entities to Google Sheets maps form fields to spreadsheet columns and automatically updates sheets when forms are submitted.

= About WPSyncSheets =

<a rel="nofollow" href="https://www.wpsyncsheets.com/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description">WPSyncSheets</a> is a leading plugin suite built to connect WordPress and WooCommerce platforms with <strong>Google Sheets</strong>. Our mission is to help businesses automate data transfer, simplify operations, and reduce repetitive tasks through real-time, two-way data synchronization. 

With over 9+ purpose-built plugins, WPSyncSheets enables:

* Smooth export/import of WooCommerce and WordPress data
* Bulk content updates through spreadsheets
* Live syncing of form submissions across popular form plugins
* Easy spreadsheet-based product management

Whether you're running an eCommerce store, collecting leads, or managing blog content, WPSyncSheets lets you <strong>automate your workflow</strong>—no code required.

👉 Learn more on our [Official Website](https://www.wpsyncsheets.com/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description)
📈 Upgrade to [WPSyncSheets Pro](https://www.wpsyncsheets.com/wpsyncsheets-for-woocommerce/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description) for the full automation suite
💬 Have questions? Contact Our [Support Team](https://www.wpsyncsheets.com/support-tickets/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description)

== Frequently Asked Questions ==

= Can the plugin export WooCommerce products with images? =

Yes, the plugin can export WooCommerce products with images from your WooCommerce store to Google Sheets. 

= Does the plugin support the export of variation products? =

Yes, the plugin supports the export of variation products from your WooCommerce store into Google Sheets. 

= Does the plugin support multisite? =

Yes, the plugin supports multisite exports to Google Sheets.

= Does the plugin export WooCommerce customers and coupons? =

Yes, the plugin can export WooCommerce customers and coupons into Google Sheets. 

= Does the plugin export posts, pages, and custom post types? =

No, the plugin does not export posts, pages, and custom post types. However, we have a different plugin called [WPSyncSheets For Core](https://www.wpsyncsheets.com/wpsyncsheets-for-core/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description) that can export those in Google Sheets. 

= Can the plugin import orders in WooCommerce? =

No, it’s a WooCommerce exporter plugin and cannot import orders in WooCommerce. However, we have a paid plugin called [WPSyncSheets For WooCommerce Pro](https://www.wpsyncsheets.com/wpsyncsheets-for-woocommerce/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description) that allows the import of orders into WooCommerce. 

= Can the plugin import WooCommerce product? =

No, it’s a WooCommerce exporter plugin and cannot import products in WooCommerce. However, we have a paid plugin called [WPSyncSheets For WooCommerce Pro](https://www.wpsyncsheets.com/wpsyncsheets-for-woocommerce/?utm_source=wp-repo&utm_campaign=wpsyncsheets-for-woocommerce&utm_medium=description) that allows the import of orders into WooCommerce.

== Installation ==

1. Upload the entire `wpsyncsheets-woocommerce` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the **Plugins** screen (**Plugins > Installed Plugins**).

You will find **WPSyncSheets Lite For WooCommerce** menu in your WordPress admin screen.

For basic usage, have a look at the [plugin's Documentation](https://docs.wpsyncsheets.com/wpssw-introduction/).

== Screenshots ==

1.  Google API Integration Settings
2.  WooCommerce Order Export Settings
3.  WooCommerce Product Export Settings
4.  WooCommerce Customer Export Settings
5.  WooCommerce Coupon Export Settings
6.  WooCommerce Order Enable Settings
7.  WooCommerce Product Enable Settings
8.  WooCommerce Customer Enable Settings
9.  WooCommerce Coupon Enable Settings
10. WooCommerce Order Default Sheet Headers
11. WooCommerce Product Default Sheet Headers
12. WooCommerce Customer Default Sheet Headers
13. WooCommerce Coupon Default Sheet Headers
14. General Settings
15. Google Spreadsheet Orders

== Changelog ==

= 2.0.7 =
* Tested with WooCommerce 10.3.6
* Tested with WordPress 6.9

= 2.0.6 =
* Add "Leave a Review" Functionality

= 2.0.5 =
* Optimized code

= 2.0.4 =
* Tested with WooCommerce 10.1.2
* Tested with WordPress 6.8.2

= 2.0.3 =
* Add "Upgrade to Pro" link

= 2.0.2 =
* Add Dashboard Tab

= 2.0.1 =
* Add Feedback Form Popup
* UI & UX Changes

= 2.0.0 =
* UI/UX changes

= 1.9.9 =
* Fix - Resolved error caused by calling get_refunds() on WC_Order_Refund object.

= 1.9.8 =
* Optimized code

= 1.9.7 =
* Tested with WooCommerce 9.8.5

= 1.9.6 =
* Country names updated to 2-letter country codes for customer setting.

= 1.9.5 =
* UI/UX changes

= 1.9.4 =
* Country names updated to 2-letter country codes.

= 1.9.3 =
* Fixed: Resolved an issue with the refresh token.

= 1.9.2 =
* Added is_plugin_active() function_exists for improved security in plugin operations.

= 1.9.1 =
* Performed user capability check for secure operation execution.

= 1.9 =
* Added nonce functionality for improved security in plugin operations.

= 1.8.2 =
* Optimized code

= 1.8.1 =
* Tested with WordPress 6.7.1
* Updated & Tested with Guzzle Library 7.9.2

= 1.8 =
* Added WooCommerce Export Customer Settings
* Added WooCommerce Export Coupon Settings
* Optimized code

= 1.7.1 =
* UI/UX changes
* Optimized code

= 1.7 =
* New Designs integration
* Tested with WordPress 6.6.1
* Optimized code

= 1.6.1 =
* Optimize Click to Sync funcationality for orders
* Tested with WordPress 6.6
* Optimized code

= 1.6 =
* Add Compatibility with HPOS WooCommerce
* Optimized code

= 1.5 =
* Optimized code

= 1.4 =
* Added Clear Spreadsheet Button
* Added WooCommerce Export Product Settings
* Optimized code

= 1.3 =

* Optimized code

= 1.2 =

* Optimized code
* Coding Standards Improvement & Security Patch

= 1.1 =

* Optimized code
* Download Spreadsheet Button
* Load Library

= 1.0 =

* Initial Version
const path = require("path");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const RemoveEmptyScriptsPlugin = require( 'webpack-remove-empty-scripts' );

module.exports = {
    externals: {
		jquery: 'jQuery',
	},
    entry: {
        "wpsslw-admin-script": "./assets/js/wpsslw-admin-script.js",
        "wpsslw-general": "./assets/js/wpsslw-general.js",
        "wpsslw-ui": "./assets/js/wpsslw-ui.js",
        "admin-feedback": "./feedback/js/admin-feedback.js",
        // CSS Files
        "wpsslw-admin-review": "./assets/css/wpsslw-admin-review.css",
        "wpsslw-admin-style": "./assets/css/wpsslw-admin-style.css",
        "wpsslw-ui-style": "./assets/css/wpsslw-ui-style.css",
        "admin-feedback-style": "./feedback/css/admin-feedback-style.css"
    },

    output: {
        path: path.resolve(__dirname, "./assets"),
        filename: "js/build/[name].js",
        clean: false,
    },

    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: "babel-loader" // optional, @wordpress/scripts provides env config automatically
            },
            {
                test: /\.(scss|css)$/,
                use: [
                    MiniCssExtractPlugin.loader,
                    {
                        loader: "css-loader",
                        options: {
                            url: false // important for WP — avoids image path rewriting
                        }
                    },
                    {
                        loader: "postcss-loader",
                        options: {
                            postcssOptions: {
                                plugins: [require("autoprefixer")]
                            }
                        }
                    },
                    "sass-loader"
                ]
            }
        ]
    },

    plugins: [
        new RemoveEmptyScriptsPlugin(),
        new MiniCssExtractPlugin({
            filename: "css/build/[name].css"
        })
    ]
};

<?php
/**
 * Main WPSyncSheets_For_WooCommerce namespace.
 *
 * @since 1.0.0
 * @package wpsyncsheets-woocommerce
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
if ( ! class_exists( 'WPSSLW_Coupon_Pro' ) ) :

    /**
	 * Class WPSSLW_Order.
	 */
	class WPSSLW_Coupon_Pro extends WPSSLW_Settings {

		/**
		 * Initialization
		 */
		public static function init() {
		}

        public static function wpsslw_woocommerce_admin_wpsslw_coupon_pro_html() {
         
        ?>
		
		<!-- Schedule Auto Sync  -->
		<div class="generalSetting-section coupon_spreadsheet_row coupon_autosync_autosynctr auto_sync_scheduling" id="couponautosynctr">
			<div class="generalSetting-left">
				<h4>
					<span class="wpssw-tooltio-link tooltip-right">
						Schedule Auto Sync<span class="tooltip-text">Pro</span>
					</span>
				</h4>
				<p>Stay updated with automatic synchronization by setting specific intervals to sync the data effortlessly.</p>
				<div class="bg-gray">
					<div class="generalSetting-autosynctr-row td-radio-btn-row mb-0">     
						<div class="auto_sync_schedulecontainer coupon_autosync_schedulecontainer mb-0 disabled-pro-version">
							<input type="radio" name="coupon_autosync_scheduling_enable" value="1" checked="checked" id="coupon_autosync_autoschedule">
							<label for="">Automatic Scheduling</label>
						</div>	
						<div class="coupon_autosync_schedulecontainer auto_sync_schedulecontainer mb-0 disabled-pro-version">
							<input type="radio" name="coupon_autosync_scheduling_enable" value="0"  id="coupon_autosync_donotschedule">
							<label for="">Do Not Schedule</label>
						</div>
					</div>
					<div id="coupon-autosync-automatic-scheduling" class="automatic_scheduling_container" style="">
						<div class="auto_sync_schedulecontainer coupon_autosync_schedulecontainer disabled-pro-version">
							<div class="input">
								<input type="radio" name="coupon_autosync_scheduling_run_on" value="recurrence" id="coupon_autosync_recurrenceradio" checked="checked">
								<label for="">Schedule Recurrence</label>
							</div>
							<select name="coupon_autosync_schedule_recurrence" id="coupon_autosync_schedule_recurrence" class="schedule_recurrence">
									<option value="ten_minutes">Every Ten Minutes</option>
									<option value="thirty_minutes">Every Thirty Minutes</option>
									<option value="once_daily">Once Daily</option>
									<option value="twice_daily">Twice Daily</option>
									<option value="fifteen_days">Every Fifteen Days</option>
									<option value="monthly">Monthly</option>
							</select>
						</div>
						<div class="auto_sync_schedulecontainer coupon_autosync_schedulecontainer disabled-pro-version">
							<div class="input">
								<input type="radio" name="coupon_autosync_scheduling_run_on" value="weekly" id="coupon_autosync_weeklyradio">
								<label for="">Every week on...</label>
							</div>
							<input type="hidden" name="coupon_autosync_scheduling_weekly_days" value="" id="coupon_autosync_weekly_days">
							<ul class="days-of-week coupon-autosync-days-of-week" id="coupon_autosync_weekly" style="display: none;">
								<li data-day="monday" class="">Mon</li>
								<li data-day="tuesday" class="">Tue</li>
								<li data-day="wednesday" class="">Wed</li>
								<li data-day="thursday" class="">Thu</li>
								<li data-day="friday" class="">Fri</li>
								<li data-day="saturday" class="">Sat</li>
								<li data-day="sunday" class="">Sun</li>
							</ul>
						</div>
						<div class="auto_sync_schedulecontainer coupon_autosync_schedulecontainer disabled-pro-version">
							<div class="input">
								<input type="radio" name="coupon_autosync_scheduling_run_on" value="onetime" id="coupon_autosync_onetime">
								<label for="">One time run at</label>
							</div>
							<div id="coupon_autosync_scheduling_date" class="scheduling_date" style="display: none;">
								<input type="date" name="coupon_autosync_scheduling_date" autocomplete="off" value="2025-06-09">
								<input type="time" name="coupon_autosync_scheduling_time" autocomplete="off" value="04:41">
							</div>
						</div>
			        </div>
				</div>
			</div>
		</div>

		<!-- Import Coupons  -->
		<div valign="top" id="import_coupon_checkbox_row" class="coupon_spreadsheet_row generalSetting-section coupon-import-section-row import-section-row ">
			<div class="ord-import-section import-section">	
				<div scope="row" class="titledesc generalSetting-left">
					<h4>
						<span class="wpssw-tooltio-link tooltip-right">
							Import Coupons<span class="tooltip-text">Pro</span>
						</span>
					</h4>
					<p>Need to import coupons from another sheet? No problem! Use the "Import" button, but remember to back up your database before doing so to avoid any data loss. 
					<a href="https://docs.wpsyncsheets.com/how-to-import-coupons/" target="_blank">How to Import Coupons?</a> </p>
				</div>
				<div class="forminp generalSetting-right disabled-pro-version">      
					<label for="">
						<input name="import_coupon_checkbox" id="import_coupon_checkbox" type="checkbox" class="" value="1"><span class="checkbox-switch"></span><span class="checkbox-switch"></span> 		
					</label> 
				</div>
			</div>
		</div>

		<!-- Inherit Styles  -->
		<div class="inheritStyles generalSetting-section coupon_spreadsheet_row">
			<div class="titledesc generalSetting-left">
				<h4>
                    <span class="wpssw-tooltio-link tooltip-right">
                        Inherit Styles<span class="tooltip-text">Pro</span>
                    </span>
                </h4>
				<p>This dropdown allows you to choose whether the new row should inherit the style from the row above it. The available options are "Yes" to inherit the style, "No" to not inherit the style, or "None" to leave the style inheritance unaffected.  <a href="https://docs.wpsyncsheets.com/how-to-use-inherit-style-option/" target="_blank">How to use inherit style option?</a></p>
			</div>
			<div class="forminp generalSetting-right disabled-pro-version">
				<label for="">
					<select name="coupon_inherit_style">
						<option value="yes">Yes</option>
						<option value="no">No</option>
						<option value="none" selected="">None</option>
					</select>
				</label>
			</div>
		</div>
        
            
        <?php
        }

    }

WPSSLW_Coupon_Pro::init();
	endif;
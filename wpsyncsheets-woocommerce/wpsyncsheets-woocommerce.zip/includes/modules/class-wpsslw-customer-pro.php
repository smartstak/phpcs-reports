<?php
/**
 * Main WPSyncSheets_For_WooCommerce namespace.
 *
 * @since 1.0.0
 * @package wpsyncsheets-woocommerce
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
if ( ! class_exists( 'WPSSLW_Customer_Pro' ) ) :

    /**
	 * Class WPSSLW_Order.
	 */
	class WPSSLW_Customer_Pro extends WPSSLW_Settings {

    
        /**
		 * Instance of WPSSLW_Google_API_Functions
		 *
		 * @var $instance_api
		 */
		protected static $instance_api = null;
		/**
		 * Initialization
		 */
		public static function init() {
			//$wpsslw_include = new WPSSLW_Include_Action();
		}

        public static function wpsslw_woocommerce_admin_wpsslw_customer_pro_html() {
         
        ?>

		<!-- Add Custom Static Headers -->
        <div class="generalSetting-section cust_spreadsheet_row">
			<div scope="row" class="titledesc generalSetting-left">
				<h4>
                    <span class="wpssw-tooltio-link tooltip-right">
                        Add Custom Static Headers<span class="tooltip-text">Pro</span>
                    </span>
                </h4>
				<p>Want to add your custom headers? Enable this button, and with a click of the "Add" button, you can create static header-value pairs to customize your header list further.</p>
			</div>
			<div class="forminp wpsswpd15 generalSetting-right disabled-pro-version">              
				<label for="">
					<input name="custom_customer_header_action" id="custom_customer_header_action" type="checkbox" class="" value="1"><span class="checkbox-switch"></span> 							
				</label>  
			</div>
		</div>

		<!-- Schedule Auto Sync -->
		<div class="generalSetting-section cust_spreadsheet_row cust_autosync_autosynctr auto_sync_scheduling" id="custautosynctr">
			<div class="generalSetting-left">
				<h4>
					<span class="wpssw-tooltio-link tooltip-right">
						Schedule Auto Sync<span class="tooltip-text">Pro</span>
					</span>
				</h4>
				<p>Stay updated with automatic synchronization by setting specific intervals to sync the data effortlessly.</p>
				<div class="bg-gray">
					<div class="generalSetting-autosynctr-row td-radio-btn-row mb-0">     
						<div class="auto_sync_schedulecontainer cust_autosync_schedulecontainer mb-0 disabled-pro-version">
							<input type="radio" name="cust_autosync_scheduling_enable" value="1" checked="checked" id="cust_autosync_autoschedule">
							<label for="">Automatic Scheduling</label>
						</div>	
						<div class="cust_autosync_schedulecontainer auto_sync_schedulecontainer mb-0 disabled-pro-version">
							<input type="radio" name="cust_autosync_scheduling_enable" value="0" id="cust_autosync_donotschedule">
							<label for="">Do Not Schedule</label>
						</div>
					</div>
					<div id="cust-autosync-automatic-scheduling" class="automatic_scheduling_container" style="">
						<div class="auto_sync_schedulecontainer cust_autosync_schedulecontainer disabled-pro-version">
							<div class="input">
								<input type="radio" name="cust_autosync_scheduling_run_on" value="recurrence" id="cust_autosync_recurrenceradio" checked="checked">
								<label for="">Schedule Recurrence</label>
							</div>
							<select name="cust_autosync_schedule_recurrence" id="cust_autosync_schedule_recurrence" class="schedule_recurrence">
									<option value="ten_minutes">Every Ten Minutes</option>
									<option value="thirty_minutes">Every Thirty Minutes</option>
									<option value="once_daily">Once Daily</option>
									<option value="twice_daily">Twice Daily</option>
									<option value="fifteen_days">Every Fifteen Days</option>
									<option value="monthly">Monthly</option>
							</select>
						</div>
						<div class="auto_sync_schedulecontainer cust_autosync_schedulecontainer disabled-pro-version">
							<div class="input">
								<input type="radio" name="cust_autosync_scheduling_run_on" value="weekly" id="cust_autosync_weeklyradio">
								<label for="">Every week on...</label>
							</div>
							<input type="hidden" name="cust_autosync_scheduling_weekly_days" value="" id="cust_autosync_weekly_days">
							<ul class="days-of-week cust-autosync-days-of-week" id="cust_autosync_weekly" style="display: none;">
								<li data-day="monday" class="">Mon</li>
								<li data-day="tuesday" class="">Tue</li>
								<li data-day="wednesday" class="">Wed</li>
								<li data-day="thursday" class="">Thu</li>
								<li data-day="friday" class="">Fri</li>
								<li data-day="saturday" class="">Sat</li>
								<li data-day="sunday" class="">Sun</li>
							</ul>
						</div>
						<div class="auto_sync_schedulecontainer cust_autosync_schedulecontainer disabled-pro-version">
							<div class="input">
								<input type="radio" name="cust_autosync_scheduling_run_on" value="onetime" id="cust_autosync_onetime">
								<label for="">One time run at</label>
							</div>
							<div id="cust_autosync_scheduling_date" class="scheduling_date" style="display: none;">
								<input type="date" name="cust_autosync_scheduling_date" autocomplete="off" value="2025-06-09">
								<input type="time" name="cust_autosync_scheduling_time" autocomplete="off" value="05:05">
							</div>
						</div>
			        </div>
				</div>
			</div>
		</div>

		<!-- Import Customers -->
		<div valign="top" id="import_customer_checkbox_row" class="cust_spreadsheet_row checkbox_margin generalSetting-section import-section-row ">	
			<div class="cust-import-section import-section">	
				<div class="titledesc generalSetting-left">
					<h4>
						<span class="wpssw-tooltio-link tooltip-right">
							Import Customers<span class="tooltip-text">Pro</span>
						</span>
					</h4>
					<p>Need to import customers from another sheet? No worries! Use the 'Import' button, but don't forget to back up your database before doing so. 
					<a href="https://docs.wpsyncsheets.com/how-to-import-customers/" target="_blank">How to Import Customers?</a>  
				</p></div>
				<div class="forminp generalSetting-right disabled-pro-version">      
					<label for="">
						<input name="import_customer_checkbox" id="import_customer_checkbox" type="checkbox" class="" value="1"><span class="checkbox-switch"></span><span class="checkbox-switch"></span> 		
					</label> 
				</div>
			</div>
		</div>

		<!-- Inherit Styles -->
		<div class="inheritStyles generalSetting-section cust_spreadsheet_row">
			<div class="titledesc generalSetting-left">
				<h4>
                    <span class="wpssw-tooltio-link tooltip-right">
                        Inherit Styles<span class="tooltip-text">Pro</span>
                    </span>
                </h4>
				<p>This dropdown allows you to choose whether the new row should inherit the style from the row above it. The available options are "Yes" to inherit the style, "No" to not inherit the style, or "None" to leave the style inheritance unaffected.  <a href="https://docs.wpsyncsheets.com/how-to-use-inherit-style-option/" target="_blank">How to use inherit style option?</a></p>
			</div>
			<div class="forminp generalSetting-right disabled-pro-version">
				<label for="">
					<select name="cust_inherit_style">
						<option value="yes" selected="">Yes</option>
						<option value="no">No</option>
						<option value="none">None</option>
					</select>
				</label>
			</div>
		</div>
           
        <?php
        }

    }

WPSSLW_Customer_Pro::init();
	endif;
<?php
/**
 * Main WPSyncSheets_For_WooCommerce namespace.
 *
 * @since 1.0.0
 * @package wpsyncsheets-woocommerce
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
if ( ! class_exists( 'WPSSLW_General_Settings_Pro' ) ) :

    /**
	 * Class WPSSLW_Order.
	 */
	class WPSSLW_General_Settings_Pro extends WPSSLW_Settings {

		/**
		 * Initialization
		 */
		public static function init() {
		}

        public static function wpsslw_woocommerce_admin_wpsslw_general_settings_pro_html() {
         
        ?>

        <!-- Row Background Color -->
		<div class="generalSetting-section">
			<div class="generalSetting-left">
				<input type="hidden" id="wpssw_general_settings" name="wpssw_general_settings" value="03889056a0"><input type="hidden" name="_wp_http_referer" value="/ColorUpdates/wp-admin/admin.php?page=wpsyncsheets-for-woocommerce">
				<h4>
					<span class="wpssw-tooltio-link tooltip-right">
						Row Background Color<span class="tooltip-text">Pro</span>
					</span>
				</h4>
				<p>The background color of rows is automatically determined based on their respective ID. Alternating colors are assigned to create a visually pleasing and organized appearance.</p>
				<div class="bg-color-oddeven disabled-pro-version">
				<input type="color" id="color_code_odd" name="oddcolor" value="#d8e0fd"><label for=""> Odd Rows</label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
				<input type="color" id="color_code_even" name="evencolor" value="#ebd6ff"><label for=""> Even Rows</label>
				</div>
			</div>
			<div class="generalSetting-right disabled-pro-version">				
				<label for="">
					<input name="color_code" id="color_code" type="checkbox" class="" value="1"><span class="checkbox-switch"></span>
				</label>
			</div>
		</div>
		
		<!-- Row Input Format Option -->
		 <div class="generalSetting-section">
			<div class="generalSetting-left">
				<h4>
					<span class="wpssw-tooltio-link tooltip-right">
						Row Input Format Option<span class="tooltip-text">Pro</span>
					</span>
				</h4>
				<p>This option allows you to specify how the input data should be interpreted. For further information, refer to the provided Link for more details,<a href="https://developers.google.com/sheets/api/reference/rest/v4/ValueInputOption" target="_blank"> click here.</a></p>
			</div>
			<div class="generalSetting-right disabled-pro-version">
				<select name="inputoption">
					<option value="USER_ENTERED" selected="">USER ENTERED</option>
					<option value="RAW">RAW</option>
				</select>					
			</div>
		</div>

		<!-- Price Format -->
		 <div class="generalSetting-section price-format-section">
			<div class="generalSetting-left">
				<h4>
					<span class="wpssw-tooltio-link tooltip-right">
						Price Format<span class="tooltip-text">Pro</span>
					</span>
				</h4>
				<p>Customize the format for displaying price values. If you choose the "Values with Symbol" option, a symbol will be appended to the price values, while the "Values" option will retain the entered values as they are.</p>
			</div>
			<div class="generalSetting-right disabled-pro-version">
				<select name="wpssw_price_format">
					<option value="plain" selected="">Only Values</option>
					<option value="formatted">Values with Symbol</option>
				</select>					
			</div>
		</div>

        <!-- Graph Sheets -->
        <div class="generalSetting-section graphSheets-section">
			<div class="generalSetting-left">
					<h4>
					<span class="wpssw-tooltio-link tooltip-right">
						Graph Sheets<span class="tooltip-text">Pro</span>
					</span>
				</h4>
					<p>With the settings provided, Google Spreadsheet will automatically generate graph sheets according to your preferences. Clicking the "Regenerate" button will create a new graph with the latest data, keeping your visuals up-to-date.</p>
					<div class="wpssw-section-6 form-table graph_spreadsheet_row">
						<div class="graphSheets-box disabled-pro-version">
							<div class="titledesc">
								<div class="graph-header">
									<label>Sales Orders</label>
									<div class="forminp forminp-checkbox inside-checkbox disabled-pro-version">  
										<label for="">
											<input name="graphsheets_list[]" id="sales_orders_graph" type="checkbox" class="sales" value="sales_orders_graph"><span class="checkbox-switch-new"></span> 							
										</label>
									</div>
								</div>
							</div>
							<div class="graph-img sales-tdclass">
								<label>
									<input type="radio" name="sales_orders_graph_type" value="column" class="graph-radio-button" required="">
									<span class="graph_type_radio">
									<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/bar_chart.png' ); ?>">
								</span>
								</label>
								<label>
									<input type="radio" name="sales_orders_graph_type" value="line" checked="" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/line_chart.png' ); ?>">
									</span>
								</label>
								<label>
									<input type="radio" name="sales_orders_graph_type" value="pie" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/pie_chart.png' ); ?>">
									</span>
								</label>
							</div>
							<div class="graph-regenerateBtn sales-tdclass">  
								<a href="javascript:void(0)" id="regenerate_sales_graph" class="graph-regenerate wpssw-button">Regenerate </a>
								<img src="images/spinner.gif" id="sales_chartloader" class="chartloader">
							</div>
						</div>
						<div class="graphSheets-box disabled-pro-version">
							<div class="titledesc">
								<div class="graph-header">
									<label>Total Orders</label>
									<div class="forminp forminp-checkbox inside-checkbox disabled-pro-version">  
										<label for="">
											<input name="graphsheets_list[]" id="total_orders_graph" type="checkbox" class="total" value="total_orders_graph"><span class="checkbox-switch-new"></span>				
										</label>
									</div>
								</div>
							</div>
							<div class="graph-img total-tdclass">
								<label>
									<input type="radio" name="total_orders_graph_type" value="column" checked="" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/bar_chart.png' ); ?>">
									</span>
								</label>
								<label>
									<input type="radio" name="total_orders_graph_type" value="line" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/line_chart.png' ); ?>">
									</span>
								</label>
								<label>
									<input type="radio" name="total_orders_graph_type" value="pie" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/pie_chart.png' ); ?>">
									</span>
								</label>
							</div>
							<div class="graph-regenerateBtn total-tdclass">  	
								<a href="javascript:void(0)" id="regenerate_total_graph" class="graph-regenerate wpssw-button ">Regenerate </a>
								<img src="images/spinner.gif" id="total_chartloader" class="chartloader">			
							</div>
						</div>
						<div class="graphSheets-box disabled-pro-version">
							<div class="titledesc">
								<div class="graph-header">
									<label>Products Sold</label>
									<div class="forminp forminp-checkbox inside-checkbox disabled-pro-version">  
										<label for="">
											<input name="graphsheets_list[]" id="products_sold_graph" type="checkbox" class="product" value="products_sold_graph"><span class="checkbox-switch-new"></span> 							
										</label>
									</div>
								</div>
							</div>
							<div class="graph-img product-tdclass">
								<label>
									<input type="radio" name="products_sold_graph_type" value="column" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/bar_chart.png' ); ?>">
									</span>
								</label>
								<label>
									<input type="radio" name="products_sold_graph_type" value="line" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/line_chart.png' ); ?>">
									</span>
								</label>
								<label>
									<input type="radio" name="products_sold_graph_type" value="pie" checked="" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/pie_chart.png' ); ?>">
									</span>
								</label>
							</div>
							<div class="graph-regenerateBtn product-tdclass">  	
								<a href="javascript:void(0)" id="regenerate_product_graph" class="graph-regenerate wpssw-button ">Regenerate </a>
								<img src="images/spinner.gif" id="product_chartloader" class="chartloader">			
							</div>
						</div>
						<div class="graphSheets-box disabled-pro-version">
							<div class="titledesc">
								<div class="graph-header">
									<label>Total Customers</label>
									<div class="forminp forminp-checkbox inside-checkbox disabled-pro-version">  
										<label for="">
											<input name="graphsheets_list[]" id="total_customers_graph" type="checkbox" class="customers" value="total_customers_graph"><span class="checkbox-switch-new"></span> 							
										</label>
									</div>
								</div>
							</div>
							<div class="graph-img customers-tdclass disabled-pro-version">
								<label>
									<input type="radio" name="total_customers_graph_type" value="column" checked="" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/bar_chart.png' ); ?>">
									</span>
								</label>
								<label>
									<input type="radio" name="total_customers_graph_type" value="line" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/line_chart.png' ); ?>">
									</span>
								</label>
								<label>
									<input type="radio" name="total_customers_graph_type" value="pie" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/pie_chart.png' ); ?>">
									</span>
								</label>
							</div>
							<div class="graph-regenerateBtn customers-tdclass">  	
								<a href="javascript:void(0)" id="regenerate_customers_graph" class="graph-regenerate wpssw-button ">Regenerate </a>
								<img src="images/spinner.gif" id="customers_chartloader" class="chartloader">			
							</div>
						</div>
						<div class="graphSheets-box disabled-pro-version">
							<div class="titledesc">
								<div class="graph-header">
									<label>Total Used Coupons</label>
									<div class="forminp forminp-checkbox inside-checkbox disabled-pro-version">  
										<label for="">
											<input name="graphsheets_list[]" id="total_used_coupons_graph" type="checkbox" class="used-coupons" value="total_used_coupons_graph"><span class="checkbox-switch-new"></span>			
										</label>
									</div>
								</div>
							</div>
							<div class="graph-img used-coupons-tdclass">
								<label>
									<input type="radio" name="total_used_coupons_graph_type" value="column" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/bar_chart.png' ); ?>">
									</span>
								</label>
								<label>
									<input type="radio" name="total_used_coupons_graph_type" value="line" checked="" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/line_chart.png' ); ?>">
									</span>
								</label>
								<label>
									<input type="radio" name="total_used_coupons_graph_type" value="pie" class="graph-radio-button" required="">
									<span class="graph_type_radio">
										<img src="<?php echo esc_url( WPSSLW_URL . 'assets/images/pie_chart.png' ); ?>">
									</span>
								</label>
							</div>
							<div class="graph-regenerateBtn used-coupons-tdclass">  	
								<a href="javascript:void(0)" id="regenerate_used_coupons_graph" class="graph-regenerate wpssw-button ">Regenerate </a>
								<img src="images/spinner.gif" id="used_coupons_chartloader" class="chartloader">			
							</div>
						</div>
					</div>
			</div>
			<div class="generalSetting-right disabled-pro-version">				
				<label for="">
					<input name="graph_sheet" id="graph_sheet" type="checkbox" class="" value="yes"><span class="checkbox-switch"></span>
				</label>
			</div>
		</div>

            
        <?php
        }

    }

WPSSLW_General_Settings_Pro::init();
	endif;
<?php
/**
 * Main WPSyncSheets_For_WooCommerce namespace.
 *
 * @since 1.0.0
 * @package wpsyncsheets-woocommerce
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
if ( ! class_exists( 'WPSSW_Product_Pro' ) ) :

    /**
	 * Class WPSSLW_Order.
	 */
	class WPSSW_Product_Pro extends WPSSLW_Settings {

    
        /**
		 * Instance of WPSSLW_Google_API_Functions
		 *
		 * @var $instance_api
		 */
		protected static $instance_api = null;
		/**
		 * Initialization
		 */
		public static function init() {
			//$wpsslw_include = new WPSSLW_Include_Action();
		}

        public static function wpsslw_woocommerce_admin_wpsslw_product_pro_html() {
         
        ?>

        <!-- Add Custom Headers from Metadata  -->
        <div class="generalSetting-section prd_spreadsheet_row">
            <div scope="row" class="titledesc generalSetting-left">
                <h4>
                    <label>
                        <span class="wpssw-tooltio-link tooltip-right">
                            Add Custom Headers from Metadata<span class="tooltip-text">Pro</span>
                        </span>
                    </label>	
                </h4>
                <p>You can enable this option to include your preferred custom headers for further customization. With the "Add" button, you can effortlessly add static header-value pairs to the list.</p> 
            </div>
            <div class="forminp wpsswpd15 generalSetting-right disabled-pro-version">              
                <label for="" class="wpssw-ajax-checkbox-row ">
                    <input name="custom_product_header_action" id="custom_product_header_action" type="checkbox" class="" value="1"><span class="checkbox-switch"></span> 							
                </label>
            </div>
        </div>

        <!-- Product Categories as Sheets  -->
        <div valign="top" id="product_categories_as_sheet_row" class="prd_spreadsheet_row checkbox_margin generalSetting-section">
            <div class="checkbox-setting-row">
                <div scope="row" class="titledesc generalSetting-left">
                    <h4>
                        <label>
                            <span class="wpssw-tooltio-link tooltip-right">
                                Product Categories as Sheets<span class="tooltip-text">Pro</span>
                            </span>
                        </label>	
                    </h4>
                    <p>This setting lets you create product categories as sheet within your existing spreadsheet, where you can manage all your store product data.</p>
                </div>
                <div class="forminp generalSetting-right">      
                    <label for="" class="wpssw-ajax-checkbox-row disabled-pro-version">
                        <input name="product_categories_as_sheet" id="product_categories_as_sheet" type="checkbox" class="" value="1"><span class="checkbox-switch"></span><span class="checkbox-switch"></span> 
                    </label> 
                </div>
            </div>						
        </div>

        <!-- Import Products  -->
        <div valign="top" id="import_checkbox_row" class="prd_spreadsheet_row prd-import-section-row import-section-row checkbox_margin generalSetting-section">
            <div>
                <div class="ord-import-section import-section">
                    <div class="titledesc generalSetting-left">
                        <h4>
                            <span class="wpssw-tooltio-link tooltip-right">
                                Import Products<span class="tooltip-text">Pro</span>
                            </span>
                        </h4>
                        <p>
                        Easily import products from your spreadsheet to this site. Remember to take a database backup before clicking the import button as a precautionary measure. Also, use the "m/d/Y" date format while importing. Preview:-06/06/2025										<a href="https://docs.wpsyncsheets.com/how-to-import-products/" target="_blank">How to Import Products?</a></p>
                    </div>
                    <div class="forminp generalSetting-right disabled-pro-version">      
                        <label for="">
                            <input name="import_checkbox" id="import_checkbox" type="checkbox" class="" value="1" ><span class="checkbox-switch"></span><span class="checkbox-switch"></span> 		
                        </label> 
                    </div>
                </div>
                <div class="generalSetting-section prd_import_options_row import_options_row">
                    <div valign="top" id="insert_checkbox_row" class="prd_spreadsheet_row wpssw_crud_row checkbox_margin wpssw_all_crud_row">
                        <div class="titledesc generalSetting-left disabled-pro-version">
                            <label>Insert Product</label>
                        </div>
                        <div class="forminp generalSetting-right inside-checkbox disabled-pro-version">    
                            <label for="">
                                <input name="insert_checkbox" id="insert_checkbox" type="checkbox" class="" value="1" ><span class="checkbox-switch-new"></span>
                            </label> 
                        </div>
                    </div>
                    <div valign="top" id="update_checkbox_row" class="prd_spreadsheet_row wpssw_crud_row checkbox_margin wpssw_all_crud_row">
                        <div class="titledesc generalSetting-left disabled-pro-version">
                            <label>Update Product</label>
                        </div>
                        <div class="forminp generalSetting-right inside-checkbox disabled-pro-version">    
                            <label for="">
                                <input name="update_checkbox" id="update_checkbox" type="checkbox" class="" value="1"><span class="checkbox-switch-new"></span>
                            </label> 
                        </div>
                    </div>
                    <div valign="top" id="delete_checkbox_row" class="prd_spreadsheet_row wpssw_crud_row checkbox_margin wpssw_all_crud_row">
                        <div scope="row" class="titledesc generalSetting-left disabled-pro-version">
                            <label>Delete Product</label>
                        </div>
                        <div class="forminp generalSetting-right inside-checkbox disabled-pro-version">     
                            <label for="">
                                <input name="delete_checkbox" id="delete_checkbox" type="checkbox" class="" value="1"><span class="checkbox-switch-new"></span>
                            </label> 
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Schedule Auto Import  -->
        <div class="generalSetting-section wpssw_crud_row prd_spreadsheet_row product_autoimporttr auto_import_scheduling" id="prodimporttr">
            <div class="generalSetting-left">
                <h4>
                    <span class="wpssw-tooltio-link tooltip-right">
                        Schedule Auto Import<span class="tooltip-text">Pro</span>
                    </span>
                </h4>
                <p>Enable this feature and allow automatic import at your preferred intervals.</p>
                <div class="bg-gray">
                    <div class="generalSetting-autosynctr-row td-radio-btn-row mb-0">     
                        <div class="auto_import_schedulecontainer product_schedulecontainer mb-0">
                            <input type="radio" name="product_scheduling_enable" value="1" checked="checked" id="product_autoschedule">
                            <label for="" class="disabled-pro-version">Automatic Scheduling</label>
                        </div>	
                        <div class="product_schedulecontainer auto_import_schedulecontainer mb-0">
                            <input type="radio" name="product_scheduling_enable" value="0"  id="product_donotschedule">
                            <label for="" class="disabled-pro-version">Do Not Schedule</label>
                        </div>
                    </div>
                    <div id="prd-autosync-automatic-scheduling" class="automatic_scheduling_container" style="">
						<div class="auto_sync_schedulecontainer prd_autosync_schedulecontainer disabled-pro-version">
							<div class="input">
								<input type="radio" name="prd_autosync_scheduling_run_on" value="recurrence" id="prd_autosync_recurrenceradio" checked="checked">
								<label for="">Schedule Recurrence</label>
							</div>
							<select name="prd_autosync_schedule_recurrence" id="prd_autosync_schedule_recurrence" class="schedule_recurrence">
                                    <option value="ten_minutes">Every Ten Minutes</option>
                                    <option value="thirty_minutes">Every Thirty Minutes</option>
                                    <option value="once_daily">Once Daily</option>
                                    <option value="twice_daily">Twice Daily</option>
                                    <option value="fifteen_days">Every Fifteen Days</option>
                                    <option value="monthly">Monthly</option>
                            </select>
						</div>
						<div class="auto_sync_schedulecontainer prd_autosync_schedulecontainer disabled-pro-version">
							<div class="input">
								<input type="radio" name="prd_autosync_scheduling_run_on" value="weekly" id="prd_autosync_weeklyradio">
								<label for="">Every week on...</label>
							</div>
							<input type="hidden" name="prd_autosync_scheduling_weekly_days" value="" id="prd_autosync_weekly_days">
							<ul class="days-of-week prd-autosync-days-of-week" id="prd_autosync_weekly" style="display: none;">
                                <li data-day="monday" class="">Mon</li>
                                <li data-day="tuesday" class="">Tue</li>
                                <li data-day="wednesday" class="">Wed</li>
                                <li data-day="thursday" class="">Thu</li>
                                <li data-day="friday" class="">Fri</li>
                                <li data-day="saturday" class="">Sat</li>
                                <li data-day="sunday" class="">Sun</li>
                            </ul>
						</div>
						<div class="auto_sync_schedulecontainer prd_autosync_schedulecontainer disabled-pro-version">
							<div class="input">
								<input type="radio" name="prd_autosync_scheduling_run_on" value="onetime" id="prd_autosync_onetime">
								<label for="">One time run at</label>
							</div>
							<div id="prd_autosync_scheduling_date" class="scheduling_date" style="display: none;">
								<input type="date" name="prd_autosync_scheduling_date" autocomplete="off" value="2025-06-09">
								<input type="time" name="prd_autosync_scheduling_time" autocomplete="off" value="05:05">
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>

        <!-- Import\Export Product Attributes  -->
        <div valign="top" id="import_attribute_checkbox_row" class="prd_spreadsheet_row checkbox_margin generalSetting-section">
            <div scope="row" class="titledesc generalSetting-left">
                <h4>
                    <span class="wpssw-tooltio-link tooltip-right">
                        Import\Export Product Attributes<span class="tooltip-text">Pro</span>
                    </span>
                </h4>
                <p>This feature will create a dedicated "Product Attributes" sheet within your current spreadsheet, where you can conveniently store product attribute data.</p>
            </div>
            <div class="forminp generalSetting-right disabled-pro-version">      
                <label for="" class="wpssw-ajax-checkbox-row">
                    <input name="import_attribute_checkbox" id="import_attribute_checkbox" type="checkbox" class="" value="1"><span class="checkbox-switch"></span><span class="checkbox-switch"></span> 		
                </label> 
            </div>
        </div>

        <!-- Import\Export Product Categories  -->
        <div valign="top" id="import_category_checkbox_row" class="prd_spreadsheet_row checkbox_margin generalSetting-section">
            <div scope="row" class="titledesc generalSetting-left">
                <h4>
                    <span class="wpssw-tooltio-link tooltip-right">
                        Import\Export Product Categories<span class="tooltip-text">Pro</span>
                    </span>
                </h4>
                <p>This feature will create a dedicated "Product Categories" sheet within your current spreadsheet, where you can conveniently store product category data.</p>
            </div>
            <div class="forminp generalSetting-right disabled-pro-version">      
                <label for="" class="wpssw-ajax-checkbox-row">
                    <input name="import_category_checkbox" id="import_category_checkbox" type="checkbox" class="" value="1" ><span class="checkbox-switch"></span><span class="checkbox-switch"></span> 		
                </label> 
            </div>
        </div>

        <!-- Sync Product Categories  -->
        <div valign="top" id="catsynctr" class="prd_spreadsheet_row generalSetting-section prd_cat_spreadsheet_row">
            <div scope="row" class="titledesc generalSetting-left">
                <h4>
                    <span class="wpssw-tooltio-link tooltip-right">
                        Sync Product Categories<span class="tooltip-text">Pro</span>
                    </span>
                </h4>
                <p>The "Click to Sync" button will append all product categories that are not present in the sheet, without updating the existing categories.</p>
                <div class="sync-button-box disabled-pro-version">              
                    <a class="wpssw-button  wpssw-button-secondary" href="javascript:void(0)" id="catsync">
                        Click to Sync</a>
                </div>
            </div>							
        </div>

        <!-- Import Product Categories  -->
        <div valign="top" id="catimporttr" class="prd_spreadsheet_row generalSetting-section prd_cat_spreadsheet_row">
            <div scope="row" class="titledesc generalSetting-left">
                <h4>
                    <span class="wpssw-tooltio-link tooltip-right">
                        Import Product Categories<span class="tooltip-text">Pro</span>
                    </span>
                </h4>
                <p>The "Import Category" button will import your categories from sheet to this site. <a href="https://docs.wpsyncsheets.com/how-to-import-product-categories/" target="_blank">How to Import Categories?</a></p>
                <div class="import-button-box disabled-pro-version">              
                    <a class="wpssw-button  wpssw-button-secondary" href="javascript:void(0)" id="importcatsync">Import Categories</a>
                </div>
            </div>							
        </div>

        <!-- Import\Export Product Tags  -->
        <div valign="top" id="import_tag_checkbox_row" class="prd_spreadsheet_row checkbox_margin generalSetting-section">
            <div scope="row" class="titledesc generalSetting-left">
                <h4>
                    <span class="wpssw-tooltio-link tooltip-right">
                        Import\Export Product Tags<span class="tooltip-text">Pro</span>
                    </span>
                </h4>
                <p>This feature will create a dedicated "Product Tags" sheet within your current spreadsheet, where you can conveniently store product tag data.</p>
            </div>
            <div class="forminp generalSetting-right disabled-pro-version">      
                <label for="" class="wpssw-ajax-checkbox-row">
                    <input name="import_tag_checkbox" id="import_tag_checkbox" type="checkbox" class="" value="1"><span class="checkbox-switch"></span><span class="checkbox-switch"></span> 		
                </label> 
            </div>
        </div>

        <!-- Inherit Styles  -->
        <div class="inheritStyles generalSetting-section prd_spreadsheet_row">
            <div class="titledesc generalSetting-left">
                <h4>
                    <span class="wpssw-tooltio-link tooltip-right">
                        Inherit Styles<span class="tooltip-text">Pro</span>
                    </span>
                </h4>
                <p>This dropdown allows you to choose whether the new row should inherit the style from the row above it. The available options are "Yes" to inherit the style, "No" to not inherit the style, or "None" to leave the style inheritance unaffected.  <a href="https://docs.wpsyncsheets.com/how-to-use-inherit-style-option/" target="_blank">How to use inherit style option?</a></p>
            </div>
            <div class="forminp generalSetting-right disabled-pro-version">
                <label for="">
                    <select name="prd_inherit_style">
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                        <option value="none" selected="">None</option>
                    </select>
                </label>
            </div>
        </div>
            
        <?php
        }

    }

WPSSW_Product_Pro::init();
	endif;
<?php
/**
 * Main WPSyncSheets_For_WooCommerce namespace.
 *
 * @since 1.0.0
 * @package wpsyncsheets-woocommerce
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
if ( ! class_exists( 'WPSSW_Order_Pro' ) ) :

    /**
	 * Class WPSSLW_Order.
	 */
	class WPSSW_Order_Pro extends WPSSLW_Settings {

    
        /**
		 * Instance of WPSSLW_Google_API_Functions
		 *
		 * @var $instance_api
		 */
		protected static $instance_api = null;
		/**
		 * Initialization
		 */
		public static function init() {
			//$wpsslw_include = new WPSSLW_Include_Action();
		}

        public static function wpsslw_woocommerce_admin_wpsslw_order_pro_html() {
        ?>
            <!-- Add Custom Headers from Metadata  -->
            <div class="generalSetting-section ord_spreadsheet_row">
                <div class="generalSetting-left">
                    <h4>
                        <label>
                            <span class="wpssw-tooltio-link tooltip-right">
                                Add Custom Headers from Metadata<span class="tooltip-text">Pro</span>
                            </span>
                        </label>	
                    </h4>
                    <p>Enable this option to add a custom header. The selected option will determine the header value. To include a static header-value pair in your list of headers, click on the "Add" button. This allows for personalized and easy customization of your headers.</p>
                </div>
                <div class="generalSetting-right">              
                    <label for="" class="wpssw-ajax-checkbox-row disabled-pro-version">
                        <input name="custom_header_action" id="custom_header_action" type="checkbox" class="" value="1"><span class="checkbox-switch"></span> 							
                    </label> <br><br>	
                </div>
            </div>
    
            <!-- select category  -->
            <div class="generalSetting-section order-setting-producat-filter-row sheetHeaders-section ord_spreadsheet_row">
                <div>
                <div class="order-setting-producat-filter-section">
                    <div class="generalSetting-left">
                        <h4>
                            <label>
                                <span class="wpssw-tooltio-link tooltip-right">
                                    Select Category<span class="tooltip-text">Pro</span>
                                </span>
                            </label>	
                        </h4>
                        <p>
                        Enable this setting to include orders based on selected product categories in the sheet.
                        Only orders that belong to the chosen product categories will be included in the spreadsheet.
                        </p>
                    </div>
                    <div class="generalSetting-right">
                        <label for="">
                        <input name="category_filter" id="product_category_select" type="checkbox" value="1">
                        <span class="checkbox-switch disabled-pro-version"></span>
                        <img id="loaderprdcatheader" src="images/spinner.gif" alt="Loading...">
                        </label>
                    </div>
                </div>

                </div>
            </div>

            <!-- Product Name as Sheets Headers  -->
            <div class="generalSetting-section order-setting-prd-name-sheet-row sheetHeaders-section ord_spreadsheet_row" id="custom-disable-id">
                <div>
                    <div class="order-setting-prd-name-sheet-section">
                        <div class="generalSetting-left">
                            <h4>
                                <label>
                                    <span class="wpssw-tooltio-link tooltip-right">
                                        Product Name as Sheets Headers<span class="tooltip-text">Pro</span>
                                    </span>
                                </label>	
                            </h4>
                            <p>By enabling this option, our plugin will automatically create columns in the spreadsheet for all the selected product names. These columns will display their respective quantities and be added after the header option you've chosen in the 'Append after' dropdown.</p>
                        </div>
                        <div class="generalSetting-right order-setting-prd-name-sheet-right-section">
                            <label for="">
                                <img id="loaderprdheader" src="images/spinner.gif">
                                <input name="prdassheetheaders" id="prdassheetheaders" type="checkbox" class="" value="yes"><span class="checkbox-switch disabled-pro-version"></span>					
                            </label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Spreadsheet Row Order  -->
            <div class="generalSetting-section ord_spreadsheet_row">
                <div class="generalSetting-left">
                    <h4>
                        <label>
                            <span class="wpssw-tooltio-link tooltip-right">
                                Spreadsheet Row Order<span class="tooltip-text">Pro</span>
                            </span>
                        </label>	
                    </h4>
                    <p>This option allows you to set the sequence in which the rows are organized, based on the order ID. This feature is only available when you create a new spreadsheet.</p>
                    <div class="forminp radio-box-td spreadsheetOrder-radio mb-0">
                        <input type="radio" id="asc_order" name="order_ascdesc" class="manage_order disabled" value="ascorder" disabled="'disabled'"><label for="asc_order"> Ascending Order</label>
                        <input type="radio" id="desc_order" name="order_ascdesc" class="manage_order disabled" value="descorder" checked="'checked'" disabled="'disabled'"><label for="desc_order"> Descending Order</label>
                    </div>
                </div>
            </div>

            <!-- Inherit Styles    -->
            <div class="inheritStyles generalSetting-section ord_spreadsheet_row">
                <div class="titledesc generalSetting-left">
                    <h4>
                        <label>
                            <span class="wpssw-tooltio-link tooltip-right">
                                Inherit Styles<span class="tooltip-text">Pro</span>
                            </span>
                        </label>	
                    </h4>
                    <p>This dropdown allows you to choose whether the new row should inherit the style from the row above it. The available options are "Yes" to inherit the style, "No" to not inherit the style, or "None" to leave the style inheritance unaffected.  
                        <a href="https://docs.wpsyncsheets.com/how-to-use-inherit-style-option/" target="_blank">How to use inherit style option?</a></p>
                </div>
                <div class="forminp generalSetting-right">
                    <label for="">
                        <select name="order_inherit_style" class="disabled-pro-version" disabled>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                            <option value="none" selected="">None</option>
                        </select>
                    </label>
                </div>
            </div>

            <!-- Exclude Order Status from Order Notes  -->
            <div valign="top" class="exclude_order_status_from_notes generalSetting-section ord_spreadsheet_row">
                <div class="generalSetting-left">
                    <h4>
                        <label>
                            <span class="wpssw-tooltio-link tooltip-right">
                                Exclude Order Status from Order Notes<span class="tooltip-text">Pro</span>
                            </span>
                        </label>	
                    </h4>
                    <p>Enable this setting option to exculde order status change note from order notes.</p>
                </div>
                <div class="generalSetting-right">              
                    <label for="">
                        <input name="exclude_order_status_from_notes" id="id_exclude_order_status_from_notes" type="checkbox" class="" value="1"><span class="checkbox-switch disabled-pro-version"></span> 							
                    </label>
                </div>
            </div>

            <!-- Import Orders  -->
            <div class="generalSetting-section ord-import-section-row import-section-row ord_spreadsheet_row" id="import_order_checkbox_row">
                <div>
                    <div class="ord-import-section import-section">
                        <div class="generalSetting-left">
                            <h4>
                                <span class="wpssw-tooltio-link tooltip-right">
                                    Import Orders<span class="tooltip-text">Pro</span>
                                </span>
                            </h4>
                            <p>Enable this option to import orders from Google Sheets to your site. Before clicking the import button it's essential to take a database backup. 
                            <a href="https://docs.wpsyncsheets.com/how-to-import-orders/" target="_blank">How to Import Orders?</a></p>
                        </div>
                        <div class="generalSetting-right">     
                            <label for="">
                                <input name="import_order_checkbox" id="import_order_checkbox" type="checkbox" class="" value="1"><span class="checkbox-switch disabled-pro-version"></span><span class="checkbox-switch disabled-pro-version"></span> 		
                            </label> 
                        </div>
                    </div>
                </div>
            </div>

            <!-- Schedule Auto Sync  -->
            <div valign="top" class="autosynctr generalSetting-section ord_spreadsheet_row">
                <div scope="row" class="titledesc generalSetting-left">
                    <h4>
                        <span class="wpssw-tooltio-link tooltip-right">
                            Schedule Auto Sync<span class="tooltip-text">Pro</span>
                        </span>
                    </h4>
                    <p>Enabling this setting allows you to schedule automatic synchronization at specified intervals.</p>
                    <div class="generalSetting-autosynctr-row td-radio-btn-row mb-0"> 
                        <div class="schedulecontainer mb-0 disabled-pro-version">
                            <input type="radio" name="scheduling_enable" value="1" id="autoschedule" checked="checked">
                            <label for="">Automatic Scheduling</label>
                        </div>
                        <div class="schedulecontainer mb-0 disabled-pro-version">
                            <input type="radio" name="scheduling_enable" value="0" id="donotschedule">
                            <label for="">Do Not Schedule</label>
                        </div>         
                    </div>
                    <div class="generalSetting-autosynctr-row">
                        <div id="automatic-scheduling">
                            <div class="schedulecontainer disabled-pro-version">
                                <div class="input">
                                    <input type="radio" name="scheduling_run_on" value="recurrence" id="recurrenceradio" checked="checked">
                                    <label for="">Schedule Recurrence</label>
                                </div>
                                <select name="schedule_recurrence" id="schedule_recurrence">
                                        <option value="ten_minutes" selected="&quot;selected&quot;">Every Ten Minutes</option>
                                        <option value="thirty_minutes">Every Thirty Minutes</option>
                                        <option value="once_daily">Once Daily</option>
                                        <option value="twice_daily">Twice Daily</option>
                                        <option value="fifteen_days">Every Fifteen Days</option>
                                        <option value="monthly">Monthly</option>
                                </select>
                            </div>
                            <div class="schedulecontainer disabled-pro-version">
                                <div class="input">
                                    <input type="radio" name="scheduling_run_on" value="weekly" id="weeklyradio">
                                    <label for="">Every week on...</label>
                                </div>
                                <input type="hidden" name="scheduling_weekly_days" value="" id="weekly_days">
                                <ul class="days-of-week" id="weekly" style="display: none;">
                                    <li data-day="monday" class="">Mon</li>
                                    <li data-day="tuesday" class="">Tue</li>
                                    <li data-day="wednesday" class="">Wed</li>
                                    <li data-day="thursday" class="">Thu</li>
                                    <li data-day="friday" class="">Fri</li>
                                    <li data-day="saturday" class="">Sat</li>
                                    <li data-day="sunday" class="">Sun</li>
                                </ul>
                            </div>
                            <div class="schedulecontainer mb-0 disabled-pro-version">
                                <div class="input">
                                    <input type="radio" name="scheduling_run_on" value="onetime" id="onetime">
                                    <label for="">One time run at</label>
                                </div>
                                <div id="scheduling_date" style="display: none;">
                                    <input type="date" name="scheduling_date" autocomplete="off" value="2025-06-06">
                                    <input type="time" name="scheduling_time" autocomplete="off" value="09:45">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php
        }

    }

WPSSW_Order_Pro::init();
	endif;
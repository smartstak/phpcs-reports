/**
 * Admin Enqueue Script
 *
 * @package contactsheets-lite
 */

jQuery( document ).ready(
	function () {
		"use strict";
		jQuery( '.wpsslc-support' ).parent().attr( 'target','_blank' );
	}
);
